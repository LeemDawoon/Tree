/**
 * File Name : passport.js
 * Description : 인증 전략을 수행합니다.
 * Function : 1. local-signup 로컬 회원가입
 *            2. local-login 로컬 로그인
 *            3. facebook 로그인
 *            4. facebook-token 페이스북 로그인 
 **/

var LocalStrategy = require('passport-local').Strategy;
var FacebookStrategy = require('passport-facebook').Strategy;
var FacebookTokenStrategy = require('passport-facebook-token').Strategy;

var bcrypt = require('bcrypt-nodejs');
var async = require('async');

var mysql = require('mysql');
var dbConfig = require('./database');
var connectionPool = mysql.createPool(dbConfig);

var logger = require('./logger');
var facebookAuthConfig = require('./auth').facebookAuth;

module.exports = function(passport) {
  /**
   * serializeUser
   * 목적 : 세션스토어에 user_id 정보를 저장한다.*/
  passport.serializeUser(function(user, done) {
    logger.debug('passport.serializeUser()', user);
    logger.debug('passport.serializeUser() u_id : ', user.u_id);
    logger.debug('passport.serializeUser() id : ', user.id);

    done(null, user.u_id);
  });
  
  /**
   * deserializeUser
   * 목적 : user_id로 사용자 정보를 검색한 후 req.user에 사용자 정보를 담는다.*/
  passport.deserializeUser(function(u_id, done) {
    process.nextTick(function() {
      connectionPool.getConnection(function(err, connection) {
        if (err) {
          return done(err);
        }
        logger.debug("u_id : "+u_id);

        /* Table : user (사용자 정보 테이블)
         * Column :   user_id (사용자 식별자), email (이메일), nickname (별명), facebook_id (페이스북 id)  
         * SQL 설명 :  사용자 정보를 가져옵니다. */
        var getUserInfoSql =  "select u_id, u_email, u_name, u_hp, u_birth, u_fb_link, u_thumbnail, u_fb_token, u_fb_id " +
                              "from user " +
                              "where u_id = ?";
        connection.query(getUserInfoSql, [u_id], function(err, rows, fields) {
          logger.debug("rows===================> : "+rows);
          var user = {};
          user.u_id = rows[0].u_id;
          user.u_email = rows[0].u_email;
          user.u_name = rows[0].u_name;
          user.u_hp = rows[0].u_hp;
          user.u_birth = rows[0].u_birth;
          user.u_fb_link = rows[0].u_fb_link;
          user.u_thumbnail = rows[0].u_thumbnail;
          user.u_fb_token = rows[0].u_fb_token;
          user.u_fb_id = rows[0].u_fb_id;
          
          connection.release();
          logger.debug('local passport.deserializeUser()', user);
          return done(null, user);
        });
      });
    });
  });
  
  /**
   * Name : local-signup 인증전략
   * Description : member.js에서 authenticateLocalSignup 핸들러에 의해 호출되어, 회원가입 (passport의 local-signup 인증전략을 수행)
   * Parameters : req.body.email(이메일), req.body.password(비밀번호), req.body.nickname(별명)
   **/
  passport.use('local-signup', new LocalStrategy({
    usernameField: 'email',
    passwordField: 'password',
    passReqToCallback: true
  },
  function(req, email, password, done) {
    process.nextTick(function() {
      connectionPool.getConnection(function(err, connection) {
        if (err) {
          logger.error("db err"+err);
          return done(err);
        }
        
       

        /* Table : user (사용자 정보 테이블)
         * Column :   user_id (사용자 식별자), email (이메일)
         * SQL 설명 :  사용자가 회원 가입을 하기위해 입력한 email 정보가 이미 존재하는지 검사한다. */
        var checkUserEmailSql = "select u_id " +
                                "from user " +
                                "where u_email = ?";
        connection.query(checkUserEmailSql, [ email ], function(err, rows, fields) {
          if (err) {
            connection.release();
            return done(err);
          }
          if (rows.length) {
            logger.error("이미 사용중인 이메일 입니다.");
            connection.release();
            return done(null, false, '이미 사용중인 이메일 입니다.');
          } else {
            
            async.waterfall([
                function generateSalt(callback) {
                  var rounds = 10;
                  bcrypt.genSalt(rounds, function(err, salt) {
                    logger.debug('bcrypt.genSalt() ====> ' + salt + '(' + salt.toString().length +')');
                    callback(null, salt);
                  });
                },
                function hashPassword(salt, callback) {
                  bcrypt.hash(password, salt, null, function(err, hashPass) {
                    logger.debug('bcrypt.hash() ====> ' + hashPass + '(' + hashPass.length + ')');
                    var newUser = {};
                    newUser.email = email;
                    newUser.password = hashPass;
//                    newUser.nickname =req.body.nickname;
                    callback(null, newUser);
                  });
                }
            ],
            function(err, newUser) {
              if (err) {
                connection.release();
                return done(err);
              }
             
              /* Table : user (사용자 정보 테이블)
               * Column :  email (이메일), password (비밀번호), nickname (별명)
               * SQL 설명 :  회원 가입한 사용자의 필수정보를 데이터베이스에 입력한다. */
              var insertNewUserSql =  "insert into user(u_email, u_pw) " +
                                      "values(?, ?)";
              connection.query(insertNewUserSql, [ newUser.email , newUser.password ], function(err, result) {
                if (err) {
                  connection.release();
                  return done(err);
                }
                newUser.u_id = result.insertId;
                connection.release();
                return done(null, newUser);
              });
            });
          }
        });
      });
    });
  }));
  
  /**
   * Name : local-login 인증전략
   * Description : member.js에서 authenticateLocalLogin 핸들러에 의해 호출되어, 사용자 정보를 가져온 후 비밀번호를 비교한다.
   * Parameters : req.body.email(이메일), req.body.password(비밀번호)
   **/
  passport.use( 'local-login', new LocalStrategy({
    usernameField: 'email',
    passwordField: 'password',
    passReqToCallback: true
  },
  function (req, email, password, done) {
    logger.debug("local-login=====>ghgㅁㄴㅇㅁㄹㅇㄻㄴh");
    
    process.nextTick(function() {
      connectionPool.getConnection(function(err, connection) {
        if (err) {
          return done(err);
        }
      
        logger.debug("local-login=====>ghgh");
        
        /* Table : user (사용자 정보 테이블)
         * Column :   user_id (사용자 식별자), email(이메일), password (비밀번호), nickname (별명), facebook_id (페이스북 id)  
         * SQL 설명 :  사용자 정보를 가져옵니다. */
        var getUserInfoSql =  "Select u_id, u_email, u_name, u_hp, u_birth, u_fb_link, u_thumbnail, u_fb_token, u_fb_id, u_pw " +
                              "from user " +
                              "where u_email = ?";
        connection.query(getUserInfoSql, [email], function(err, rows, fields) {
          if (err) {
            connection.release();
            return done(err);
          }
          if (!rows) {
            logger.debug("local-login=====>길이 없음");
            connection.release();
            return done(null, false, '사용자를 찾을 수 없습니다.');
          }
          
          logger.debug("local-login=====>쿼리실행");
          var user = {};
          user.u_id = rows[0].u_id;
          user.u_email = rows[0].u_email;
          user.u_name = rows[0].u_name;
          user.u_hp = rows[0].u_hp;
          user.u_birth = rows[0].u_birth;
          user.u_fb_link = rows[0].u_fb_link;
          user.u_thumbnail = rows[0].u_thumbnail;
          user.u_fb_token = rows[0].u_fb_token;
          user.u_fb_id = rows[0].u_fb_id;
          
          
          connection.release();
          bcrypt.compare(password, rows[0].u_pw, function(err, result) {
            if (!result){
              logger.debug("local-login=====>비번 노노");
              return done(null, false, '비밀번호가 일치하지 않습니다.');
            }
            
            logger.debug('bcrypt.compare() ====> ' + user.password + '(' + user + ')');
            return done(null, user);
          });
        });
      });
    });
  }));

//앞에 'facebook'이 없는건 이게 기본이라
  passport.use('facebook',new FacebookStrategy({
    clientID: facebookAuthConfig.clientID,
    clientSecret: facebookAuthConfig.clientSecret,
    callbackURL: facebookAuthConfig.callbackURL
  },
  function(accessToken, refreshToken, profile, done) { //<---  passport.authenticate() 가 호출될때 호출됨
    process.nextTick(function() {
      connectionPool.getConnection(function(err, connection) {
        if (err) {
          return done(err);
        }
        
        var facebookPhoto = "https://graph.facebook.com/v2.1/me/picture?access_token=" + accessToken;
        
        var selectSql = "SELECT u_id, u_email, u_name, u_hp, u_birth, u_fb_link, u_thumbnail, u_fb_token, u_fb_id " +
                    		"FROM user " +
                    		"WHERE u_fb_id = ?";
        connection.query(selectSql, [profile.id], function(err, rows, fields) {
          if (err) {
            connection.release();
            return done(err);
          }
          if (rows.length) {
            var user = {};
            user.u_id = rows[0].u_id;
            user.u_email = rows[0].u_email;
            user.u_name = rows[0].u_name;
            user.u_hp = rows[0].u_hp;
            user.u_birth = rows[0].u_birth;
            user.u_fb_link = rows[0].u_fb_link;
            user.u_thumbnail = rows[0].u_thumbnail;
            user.u_fb_token = rows[0].u_fb_token;
            user.u_fb_id = rows[0].u_fb_id;
            
            if (accessToken !== user.u_fb_token) { // accessToken과 비교해서, 다르면 업데이트 
              var updateSql = 'UPDATE user SET u_fb_token = ?, u_thumbnail = ? WHERE u_fb_id = ?';
              connection.query(updateSql, [accessToken, facebookPhoto, profile.id], function(err, result) {
                if (err) {
                  connection.release();
                  return done(err);
                }
                connection.release();
                return done(null, user);
              });
            } else {
              connection.release();
              return done(null, user);
            }
          } else { //최초 요청시, 새로운 정보 만듬
            
            var newUser = {};
            newUser.u_fb_id = profile.id;
            newUser.u_name = profile.name.givenName + ' ' + profile.name.familyName;
            newUser.u_fb_token = accessToken;
            newUser.u_email = profile.emails[0].value;
            newUser.u_thumbnail = "https://graph.facebook.com/v2.1/me/picture?access_token=" + accessToken;
            var insertSql = 'INSERT INTO user(u_fb_id, u_name, u_fb_token, u_email, u_thumbnail) VALUES(?, ?, ?, ?, ?)';
            connection.query(insertSql, [newUser.u_fb_id, newUser.u_name, newUser.u_fb_token, newUser.u_email, newUser.u_thumbnail], function(err, result) {
              if (err) {
                connection.release();
                return done(err);
              }
              newUser.u_id = result.insertId;
              connection.release();
              return done(null, newUser);
            });
          }
        });
      });
    });
  }));
  /**
   * Name : facebook-token  인증전략
   * Description : member.js에서 authenticateFacebookLogin 핸들러에 의해 호출되어, 
   *               기존에 가입한 사용자가 있는지 확인하고, 새로운 사용자를 데이터베이스에 저장한다.
   * Parameters : req.body.access_token(엑세스 토큰)
   **/
  passport.use('facebook-token',new FacebookTokenStrategy({
    clientID: facebookAuthConfig.clientID,
    clientSecret: facebookAuthConfig.clientSecret,
  },
  function(accessToken, refreshToken, profile, done) {
    process.nextTick(function() {
      connectionPool.getConnection(function(err, connection) {
        if (err) {
          return done(err);
        }
        
        /* Table : user (사용자 정보 테이블)
         * Column :   user_id(사용자 식별자), email(이메일), nickname(별명), facebook_id(페이스북 id), facebook_token(페이스북 엑세스 토큰)  
         * SQL 설명 :  페이스북 로그인 사용자의 정보를 가져옵니다. */
        var getUserInfoSql =  "SELECT u_id, u_email, u_name, u_hp, u_birth, u_fb_link, u_thumbnail, u_fb_token, u_fb_id " +
                              "FROM user " +
                              "WHERE u_fb_id = ?";
        
        connection.query(getUserInfoSql, [profile.id], function(err, rows, fields) {
          if (err) {
            connection.release();
            return done(err);
          }
          if (rows.length) {
            
            var user = {};
            user.u_id = rows[0].u_id;
            user.u_email = rows[0].u_email;
            user.u_name = rows[0].u_name;
            user.u_hp = rows[0].u_hp;
            user.u_birth = rows[0].u_birth;
            user.u_fb_link = rows[0].u_fb_link;
            user.u_thumbnail = rows[0].u_thumbnail;
            user.u_fb_token = rows[0].u_fb_token;
            user.u_fb_id = rows[0].u_fb_id;
            
            if (accessToken !==  user.u_fb_token) { // accessToken과 비교해서, 다르면 업데이트 
              
              /* Table : user (사용자 정보 테이블)
               * Column :  facebook_id(페이스북 id), facebook_token(페이스북 엑세스 토큰)  
               * SQL 설명 :  토큰 정보를 업데이트 합니다. */
              var updateTokenSql =  "update user " +
                                    "set u_fb_token = ? " +
                                    "where u_fb_id = ?";
              connection.query(updateTokenSql, [accessToken, profile.id], function(err, result) {
                if (err) {
                  connection.release();
                  return done(err);
                }
                connection.release();
                return done(null, user);
              });
            } else {
              connection.release();
              return done(null, user);
            }
          } else { //최초 요청시, 새로운 사용자 정보 입력
            
            var newUser = {};
            newUser.u_fb_id = profile.id;
            newUser.u_name = profile.name.givenName + ' ' + profile.name.familyName;
            newUser.u_fb_token = accessToken;
            newUser.u_email = profile.emails[0].value;
            newUser.u_thumbnail = "https://graph.facebook.com/v2.1/me/picture?access_token=" + accessToken;
            
            
            /* Table : user(사용자 정보 테이블)
             * Column :  email(이메일), nickname(별명), picture(프로필 사진 path), facebook_id(페이스북 id), facebook_token(페이스북 엑세스 토큰)  
             * SQL 설명 :  페이스북 로그인틀 최초로 한 사용자의 필수정보를 데이터베이스에 입력합니다. */
            var insertNewFacebookUserSql = "INSERT INTO user(u_fb_id, u_name, u_fb_token, u_email, u_thumbnail) " +
            		                           "VALUES(?, ?, ?, ?, ?)";
            connection.query(insertNewFacebookUserSql, [newUser.u_fb_id, newUser.u_name, newUser.u_fb_token, newUser.u_email , newUser.u_thumbnail], function(err, result) {
              if (err) {
                connection.release();
                return done(err);
              }
              newUser.u_id = result.insertId;
              connection.release();
              return done(null, newUser);
            });
          }
        });
      });
    });
  }));
};

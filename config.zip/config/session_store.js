/**
 * File Name : session_store.js
 * Description : 세션스토어 데이터베이스를 설정합니다.
 **/
var server = require('./server');

module.exports = {
  host : server.dbHost,
  port : 3306,
  user : server.dbUser,
  password : server.dbPassword,
  database : server.dbName,
  useConnectionPooling : true
};


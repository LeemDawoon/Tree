/**
 * File Name : server.js
 * Description : 에서 사용하는 serverHost와 DB 정보를 관리합니다.
 **/
module.exports = {
    serverHost :"http://localhost:3000",//"http://ec2-54-64-198-242.ap-northeast-1.compute.amazonaws.com",
    dbHost : 'tree.czszosc6m2sp.ap-northeast-1.rds.amazonaws.com',//"pixx.czly8rx16cj4.ap-northeast-1.rds.amazonaws.com",
    dbUser : "dy626",
    dbPassword : "ekdns626",
    dbName : "Tree"
};
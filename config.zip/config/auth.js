/**
 * File Name : auth.js
 * Description : 로그인을 위한 페이스북과 비밀번호 찾기에서 이메일 전송을 위한, auth 정보를 관리합니다.
 * object :   1. facebookAuth
 *            2. sesAuth         
 * */

module.exports = {
  facebookAuth: {
    clientID: '801822059870569',      //test 앱
    clientSecret: '781b8ac760710066d7cf015e4f8e9968',
    callbackURL: 'http://localhost:3000/auth/facebook/callback'
  },
  sesAuth: {
    key: 'AKIAJQIVXEX4VTZMBUTQ',                        //Access Keys <--테스용. IAM에 pixx 로 따로 만들기
    secret: 'Lj9SFHF9xFyTC4FIqyvFzjJbMBDp4yCthoY5z7FD',
    region: "us-west-2"
  }
};
/**
 * File Name : database.js
 * Description : 데이터베이스를 설정합니다.
 **/
var server = require('./server');

module.exports = {
  connectionLimit: 20,
  host: server.dbHost,
  port: '3306',
  user: server.dbUser,
  password: server.dbPassword,
  database: server.dbName,
  debug: true,
  charset: 'UTF8_GENERAL_CI',
  timezone: '+0900'
};


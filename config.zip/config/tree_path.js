/**
 * File Name :tree_path.js
 * Description : tree에서 사용하는 path 정보를 관리합니다.
 * object : 1. url(이미지 요청 url)
 *          2. uploadPath (이미지 업로드 경로)
 **/
var s3Host = require('./s3').host;
module.exports = {
    // url: { 
    //   tree:s3Host+"/treetree/image/tree/",
    //   treeThumb:s3Host+"/treetree/image/tree_thumb/",
    //   profile:s3Host+"/treetree/image/profile/",
    //   profileThumb:s3Host+"/treetree/image/profile_thumb/",
    // },
    uploadPath: {
      uploads:"/../uploads",
      forest:"image/forest",
      forestThumb:"image/forest_thumb",
      profile:"image/profile",
      profileThumb:"/image/profile_thumb"
    }
};

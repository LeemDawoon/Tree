/**
 * New node file
 */
module.exports = {
  key : "AKIAJCPMVWYW6TK45NWQ",
  secret : "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",
  region : "ap-northeast-1", //Tokyo
  host : "https://s3-ap-northeast-1.amazonaws.com",
//  "hostname" : "",
  bucket : "treetree",
  imageDir : "images",
  imageACL : "public-read", //읽기만 가능
};